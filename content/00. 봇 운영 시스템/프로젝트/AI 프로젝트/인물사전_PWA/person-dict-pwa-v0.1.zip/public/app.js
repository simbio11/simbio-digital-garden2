/* 인물 사전 PWA - 로컬 스토리지 기반 CRUD + 필터 + JSON 백업/복구 */
"use strict";

const STORAGE_KEY = "person-dict.v1";
const EMOTIONS = {
  good: { label: "😊 좋음", dot: "bg-emerald-500", chip: "bg-emerald-100 text-emerald-700" },
  neutral: { label: "😐 보통", dot: "bg-slate-400", chip: "bg-slate-100 text-slate-600" },
  hard: { label: "😅 어려움", dot: "bg-rose-500", chip: "bg-rose-100 text-rose-700" },
};
const TAGS = {
  business: { label: "💼 비즈니스", chip: "bg-sky-100 text-sky-700" },
  personal: { label: "💛 사적 관계", chip: "bg-emerald-100 text-emerald-700" },
  family: { label: "👨👩👧 가족", chip: "bg-rose-100 text-rose-700" },
  school: { label: "🎓 학교", chip: "bg-violet-100 text-violet-700" },
  community: { label: "🤝 모임/커뮤니티", chip: "bg-amber-100 text-amber-700" },
};
const LEVEL_LABELS = ["", "인사", "아는 사이", "친분", "가까움", "최고 친밀"];
const LEVEL_COLORS = ["", "bg-slate-300", "bg-sky-400", "bg-emerald-400", "bg-amber-400", "bg-rose-500"];

let people = load();
let filter = "all";
let search = "";
let deferredPrompt = null;

/* ---------- 저장소 ---------- */
function load() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const data = raw ? JSON.parse(raw) : [];
    return Array.isArray(data) ? data : [];
  } catch (e) {
    console.warn("저장소 읽기 실패:", e);
    return [];
  }
}

function save() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(people));
}

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

/* ---------- 렌더링 ---------- */
function render() {
  const listEl = document.getElementById("list");
  const emptyEl = document.getElementById("empty-state");
  let items = [...people];

  if (filter === "business") items = items.filter((p) => p.tags.includes("business"));
  else if (filter === "personal") items = items.filter((p) => p.tags.includes("personal"));
  else if (filter === "level5") items = items.filter((p) => p.level >= 5);
  else if (filter === "recent") items.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

  if (search.trim()) {
    const q = search.trim().toLowerCase();
    items = items.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        (p.place || "").toLowerCase().includes(q) ||
        (p.memo || "").toLowerCase().includes(q)
    );
  }

  listEl.innerHTML = items
    .map((p) => {
      const emo = EMOTIONS[p.emotion] || EMOTIONS.neutral;
      const tagChips = p.tags
        .map((t) => {
          const meta = TAGS[t];
          return meta ? `<span class="chip ${meta.chip}">${meta.label}</span>` : "";
        })
        .join("");
      const dots = Array.from({ length: 5 }, (_, i) => {
        const on = i < p.level;
        return `<span class="level-dot ${on ? LEVEL_COLORS[p.level] : "bg-slate-200"}"></span>`;
      }).join("");
      return `
      <article class="card cursor-pointer transition hover:shadow-md active:scale-[0.99]"
               data-id="${p.id}" onclick="openDetail('${p.id}')">
        <div class="flex items-start justify-between gap-3">
          <div class="min-w-0">
            <h3 class="truncate text-base font-bold text-slate-900">${esc(p.name)}</h3>
            <p class="mt-0.5 truncate text-xs text-slate-500">
              ${p.place ? `📍 ${esc(p.place)}` : "📍 장소 미기록"}
              ${p.metAt ? ` · ${esc(p.metAt)}` : ""}
            </p>
          </div>
          <span class="chip shrink-0 ${emo.chip}">${emo.label}</span>
        </div>
        <div class="mt-2 flex items-center gap-1.5">${dots}
          <span class="ml-1 text-[11px] font-medium text-slate-500">${p.level} · ${LEVEL_LABELS[p.level]}</span>
        </div>
        ${tagChips ? `<div class="mt-2 flex flex-wrap gap-1">${tagChips}</div>` : ""}
        ${p.memo ? `<p class="mt-2 line-clamp-2 text-xs text-slate-600">${esc(p.memo)}</p>` : ""}
      </article>`;
    })
    .join("");

  emptyEl.classList.toggle("hidden", people.length > 0);
  if (people.length > 0 && items.length === 0) {
    listEl.innerHTML = `<p class="mt-8 text-center text-sm text-slate-400">검색 결과가 없어요.</p>`;
  }

  renderStats();
}

function renderStats() {
  document.getElementById("stat-total").textContent = people.length;
  document.getElementById("stat-business").textContent = people.filter((p) =>
    p.tags.includes("business")
  ).length;
  document.getElementById("stat-personal").textContent = people.filter((p) =>
    p.tags.includes("personal")
  ).length;
}

/* ---------- 모달 ---------- */
let editingId = null;

function openDetail(id) {
  const p = people.find((x) => x.id === id);
  if (!p) return;
  editingId = id;
  document.getElementById("modal-title").textContent = "인물 정보";
  document.getElementById("field-id").value = p.id;
  document.getElementById("field-name").value = p.name;
  document.getElementById("field-place").value = p.place || "";
  document.getElementById("field-met").value = p.metAt || "";
  document.getElementById("field-memo").value = p.memo || "";
  setEmotion(p.emotion || "neutral");
  setLevel(p.level || 1);
  setTags(p.tags || []);
  document.getElementById("btn-delete").classList.remove("hidden");
  openModal();
}

function openNew() {
  editingId = null;
  document.getElementById("modal-title").textContent = "새 인물 추가";
  document.getElementById("form-person").reset();
  document.getElementById("field-id").value = "";
  setEmotion("neutral");
  setLevel(1);
  setTags(["business"]);
  document.getElementById("btn-delete").classList.add("hidden");
  openModal();
}

function openModal() {
  const m = document.getElementById("modal");
  m.classList.remove("hidden");
  document.body.style.overflow = "hidden";
  setTimeout(() => document.getElementById("field-name").focus(), 50);
}

function closeModal() {
  document.getElementById("modal").classList.add("hidden");
  document.body.style.overflow = "";
}

/* 폼 선택 상태 */
function setEmotion(value) {
  document.querySelectorAll("#field-emotion .emotion-option").forEach((b) => {
    const on = b.dataset.value === value;
    b.className =
      "emotion-option rounded-xl px-2 py-2.5 text-center text-sm font-medium " +
      (on
        ? "border-2 border-indigo-500 bg-indigo-50 text-indigo-700"
        : "border border-slate-200 text-slate-600 hover:bg-slate-50");
  });
}
function getEmotion() {
  const el = document.querySelector("#field-emotion .emotion-option.border-2");
  return el ? el.dataset.value : "neutral";
}

function setLevel(value) {
  document.querySelectorAll("#field-level .level-option").forEach((b) => {
    const on = Number(b.dataset.value) === value;
    b.className =
      "level-option flex-1 rounded-xl py-2.5 text-center text-sm " +
      (on ? "border-2 border-indigo-500 bg-indigo-50 font-bold text-indigo-700" : "border border-slate-200 text-slate-600 hover:bg-indigo-50");
  });
}
function getLevel() {
  const el = document.querySelector("#field-level .level-option.border-2");
  return el ? Number(el.dataset.value) : 1;
}

function setTags(tags) {
  document.querySelectorAll(".tag-option").forEach((b) => {
    const on = tags.includes(b.dataset.tag);
    b.className =
      "tag-option chip " +
      (on ? "bg-indigo-600 text-white shadow-sm" : "bg-slate-200 text-slate-600");
    b.dataset.active = on ? "1" : "0";
  });
}
function getTags() {
  return [...document.querySelectorAll(".tag-option[data-active='1']")].map((b) => b.dataset.tag);
}

/* ---------- 저장/삭제 ---------- */
function handleSubmit(e) {
  e.preventDefault();
  const name = document.getElementById("field-name").value.trim();
  if (!name) {
    toast("이름을 입력해 주세요 🙏");
    return;
  }
  const id = document.getElementById("field-id").value;
  const record = {
    id: id || uid(),
    name,
    place: document.getElementById("field-place").value.trim(),
    metAt: document.getElementById("field-met").value,
    emotion: getEmotion(),
    level: getLevel(),
    tags: getTags(),
    memo: document.getElementById("field-memo").value.trim(),
    updatedAt: Date.now(),
  };
  if (id) {
    const idx = people.findIndex((p) => p.id === id);
    if (idx >= 0) people[idx] = { ...people[idx], ...record };
    toast("저장했어요 ✅");
  } else {
    record.createdAt = Date.now();
    people.push(record);
    toast("인물을 추가했어요 🎉");
  }
  save();
  render();
  closeModal();
}

function handleDelete() {
  const id = document.getElementById("field-id").value;
  if (!id) return;
  const p = people.find((x) => x.id === id);
  if (!confirm(`'${p ? p.name : ""}' 인물을 삭제할까요?`)) return;
  people = people.filter((x) => x.id !== id);
  save();
  render();
  closeModal();
  toast("삭제했어요 🗑️");
}

/* ---------- 백업 / 복원 ---------- */
function exportJson() {
  if (people.length === 0) {
    toast("백업할 데이터가 없어요");
    return;
  }
  const blob = new Blob([JSON.stringify(people, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `person-dict-backup-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(a.href);
  toast("백업 파일을 내려받았어요 ⬇️");
}

function importJson(file) {
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const data = JSON.parse(reader.result);
      if (!Array.isArray(data)) throw new Error("배열이 아님");
      const clean = data.map((p) => ({
        id: p.id || uid(),
        name: String(p.name || "").trim(),
        place: p.place || "",
        metAt: p.metAt || "",
        emotion: EMOTIONS[p.emotion] ? p.emotion : "neutral",
        level: Number.isInteger(p.level) && p.level >= 1 && p.level <= 5 ? p.level : 1,
        tags: Array.isArray(p.tags) ? p.tags.filter((t) => TAGS[t]) : [],
        memo: p.memo || "",
        createdAt: p.createdAt || Date.now(),
        updatedAt: p.updatedAt || Date.now(),
      })).filter((p) => p.name);
      if (clean.length === 0) throw new Error("유효한 인물 데이터 없음");
      people = clean;
      save();
      render();
      toast(`복원 완료! ${people.length}명을 불러왔어요 📥`);
    } catch (err) {
      toast("파일 형식이 올바르지 않아요 ⚠️");
      console.error("import error", err);
    }
  };
  reader.readAsText(file);
}

/* ---------- 토스트 ---------- */
let toastTimer = null;
function toast(msg) {
  const el = document.querySelector("#toast > div");
  el.textContent = msg;
  el.classList.remove("hidden");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add("hidden"), 2400);
}

/* ---------- HTML 이스케이프 ---------- */
function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

/* ---------- 이벤트 연결 ---------- */
document.addEventListener("DOMContentLoaded", () => {
  render();

  document.getElementById("btn-add").addEventListener("click", openNew);
  document.getElementById("btn-modal-close").addEventListener("click", closeModal);
  document.getElementById("modal").addEventListener("click", (e) => {
    if (e.target === e.currentTarget) closeModal();
  });
  document.getElementById("form-person").addEventListener("submit", handleSubmit);
  document.getElementById("btn-delete").addEventListener("click", handleDelete);
  document.getElementById("btn-export").addEventListener("click", exportJson);
  document.getElementById("btn-import").addEventListener("click", () =>
    document.getElementById("file-import").click()
  );
  document.getElementById("file-import").addEventListener("change", (e) => {
    if (e.target.files[0]) importJson(e.target.files[0]);
    e.target.value = "";
  });

  document.getElementById("input-search").addEventListener("input", (e) => {
    search = e.target.value;
    render();
  });

  document.querySelectorAll("#filter-chips .chip").forEach((btn) => {
    btn.addEventListener("click", () => {
      filter = btn.dataset.filter;
      document.querySelectorAll("#filter-chips .chip").forEach((b) => {
        const on = b === btn;
        b.className = "chip active:scale-95 " +
          (on ? "bg-indigo-600 text-white" : "bg-slate-200 text-slate-600 hover:bg-slate-300");
      });
      render();
    });
  });

  document.querySelectorAll("#field-emotion .emotion-option").forEach((b) =>
    b.addEventListener("click", () => setEmotion(b.dataset.value))
  );
  document.querySelectorAll("#field-level .level-option").forEach((b) =>
    b.addEventListener("click", () => setLevel(Number(b.dataset.value)))
  );
  document.querySelectorAll(".tag-option").forEach((b) => {
    b.addEventListener("click", () => {
      const set = new Set(getTags());
      if (set.has(b.dataset.tag)) set.delete(b.dataset.tag);
      else set.add(b.dataset.tag);
      setTags([...set]);
    });
  });

  /* ESC 닫기 */
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !document.getElementById("modal").classList.contains("hidden")) closeModal();
  });

  /* ---------- PWA 설치 ---------- */
  if (window.matchMedia("(display-mode: standalone)").matches) {
    document.getElementById("install-banner").classList.add("hidden");
  }
  window.addEventListener("beforeinstallprompt", (e) => {
    e.preventDefault();
    deferredPrompt = e;
    const banner = document.getElementById("install-banner");
    if (!localStorage.getItem("person-dict.install-dismissed")) banner.classList.remove("hidden");
  });
  document.getElementById("btn-install").addEventListener("click", async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    deferredPrompt = null;
    document.getElementById("install-banner").classList.add("hidden");
    localStorage.setItem("person-dict.install-dismissed", "1");
  });
  document.getElementById("btn-dismiss-install").addEventListener("click", () => {
    document.getElementById("install-banner").classList.add("hidden");
    localStorage.setItem("person-dict.install-dismissed", "1");
  });

  /* 온라인/오프라인 표시 */
  const badge = document.getElementById("offline-badge");
  const updateOnline = () => badge.classList.toggle("hidden", navigator.onLine);
  window.addEventListener("online", updateOnline);
  window.addEventListener("offline", updateOnline);
  updateOnline();

  /* 서비스 워커 등록 */
  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("sw.js").catch((err) =>
        console.warn("SW 등록 실패:", err)
      );
    });
  }
});
